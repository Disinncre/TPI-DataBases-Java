
/*Crear Base de Datos*/
CREATE DATABASE java_23558;
USE java_23558;

/*Crear Tablas*/
CREATE TABLE clientes (
  id INT(11) AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  apellido VARCHAR(40) NOT NULL,
  edad TINYINT(2) NOT NULL,
  fecha TIMESTAMP NOT NULL,
  provincia VARCHAR(30) NOT NULL
);

SELECT * FROM Clientes;

/* Ingresar Registros*/
INSERT INTO clientes (nombre, apellido, edad, fecha, provincia)
VALUES ('Juan', 'Pérez', 25, '1998-11-21', 'Buenos Aires'),
       ('María', 'Gómez', 30, '1993-07-06', 'Córdoba'),
       ('Carlos', 'López', 35, '1988-03-15', 'Santa Fe'),
       ('Laura', 'Rodríguez', 28, '1995-12-30', 'Mendoza'),
       ('Pedro', 'Fernández', 32, '1991-02-20', 'Salta');
       
 SELECT * FROM Clientes;      

