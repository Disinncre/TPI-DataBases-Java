
/* Crear Base de Datos */
CREATE DATABASE integrador_cac;

USE integrador_cac;

/* Crear Tabla oradores */
CREATE TABLE oradores (
id_orador int not null auto_increment primary key,
nombre varchar(40) not null unique,
apellido varchar(40) not null,
mail varchar(40) not null,
tema varchar(40) not null,
fecha_alta timestamp not null
);

/* Insertar Registris */
INSERT INTO oradores (nombre, apellido, mail, tema, fecha_alta)
VALUES ('Juan', 'Pérez', 'juanperez@example.com', 'Tecnología', '2023-01-05'),
  ('María', 'López', 'marialopez@example.com', 'Ciencia', '2023-02-10'),
  ('Carlos', 'Rodríguez', 'carlosrodriguez@example.com', 'Arte', '2023-03-15'),
  ('Laura', 'García', 'lauragarcia@example.com', 'Deporte', '2023-04-20'),
  ('Andrés', 'Fernández', 'andresfernandez@example.com', 'Historia', '2023-05-25'),
  ('Ana', 'Torres', 'anatorres@example.com', 'Política', '2023-06-30'),
  ('Luis', 'Ramírez', 'luisramirez@example.com', 'Medio ambiente', '2023-07-05'),
  ('Carolina', 'González', 'carolinagonzalez@example.com', 'Salud', '2023-08-10'),
  ('Martín', 'Castro', 'martincastro@example.com', 'Educación', '2023-09-15'),
  ('Gabriela', 'Silva', 'gabrielasilva@example.com', 'Economía', '2023-10-20');
  
  SELECT * FROM oradores;